# 世界與經濟｜v1.1

V1 固定 20 城、30 個一般商品槽位。以下為唯一 **V1 Candidate Dataset**；資料可換，槽位數與 ID 作為目前實作契約。價格、重量、座標與供需皆可用 Config Placeholder，不阻擋 M0。

## 20 城市世界設定

| 區域 | 城市 | 定位 | 主要低價商品 | 高需求商品 |
|---|---|---|---|---|
| 中國東南 | 泉州 | 大型海港 | 茶、瓷器、絲綢 | 香料、珠寶 |
| 中國東南 | 廣州 | 國際商港 | 絲綢、陶器、紙 | 香料、象牙 |
| 江南 | 杭州 | 工藝商業城 | 絲綢、茶、紙 | 香料 |
| 江南 | 蘇州 | 絲織中心 | 絲綢、布匹 | 藥材、珠寶 |
| 華北 | 開封 | 大型消費都會 | 書籍、紙、工藝品 | 茶、絲綢、香料 |
| 華北 | 燕京 | 北方都會 | 馬具、皮毛 | 茶、瓷器 |
| 西北 | 敦煌 | 陸路轉運站 | 皮毛 | 絲綢、茶 |
| 西南 | 成都 | 農業／工藝城 | 糧食、藥材、紙 | 鹽、珠寶 |
| 日本 | 博多 | 日本商港 | 木材、銀、刀具 | 絲綢、茶 |
| 日本 | 平安京 | 高消費城市 | 工藝品 | 絲綢、香料 |
| 朝鮮 | 開京 | 半島商業城 | 人參、紙、陶器 | 茶、香料 |
| 台灣／琉球圈 | 琉球 | 中轉港 | 魚乾、糖、木材 | 絲綢、陶器 |
| 東南亞 | 占城 | 沿海貿易港 | 香木、象牙 | 絲綢、陶器 |
| 東南亞 | 真臘 | 河港農業城 | 稻米、香木 | 鐵器、布匹 |
| 東南亞 | 三佛齊 | 海上樞紐 | 香料、樟腦 | 絲綢、瓷器 |
| 東南亞 | 馬六甲 | 國際中轉港 | 香料 | 茶、絲綢、銀 |
| 印度 | 加爾各答區域港 | 東印度港 | 棉布、香料 | 銀、瓷器 |
| 印度 | 科欽 | 香料港 | 胡椒、香料 | 絲綢、陶器 |
| 阿拉伯海 | 亞丁 | 紅海轉口港 | 乳香、香料 | 絲綢、瓷器 |
| 波斯灣 | 霍爾木茲 | 奢侈品中轉港 | 珠寶、香料 | 絲綢、茶 |

上表保留20城設定，已移除一般供需欄位中的馬匹；不直接作程式商品ID。馬匹僅存歷史與未來資源紀錄，M0不產生馬匹庫存或交易列；「工藝品／糧食／藥材」為集合敘述，不另占商品槽位。茶、紙、布匹與絲綢分別映射 tea、paper、cloth、silk；普通瓷器為 porcelain。

## 單一 30 槽位商品表

| 槽位 | id | 名稱 | category |
|---|---|---|---|
| 01 | rice | 稻米 | food |
| 02 | wheat | 小麥 | food |
| 03 | salt | 鹽 | food |
| 04 | sugar | 糖 | food |
| 05 | dried_fish | 魚乾 | food |
| 06 | tea | 普通茶葉 | agriculture |
| 07 | herbs | 藥草 | agriculture |
| 08 | ginseng | 人參 | agriculture |
| 09 | aromatic_wood | 香木 | agriculture |
| 10 | camphor | 樟腦 | agriculture |
| 11 | timber | 木材 | agriculture |
| 12 | cotton_cloth | 棉布 | textile |
| 13 | cloth | 普通布匹 | textile |
| 14 | silk | 普通絲綢 | textile |
| 15 | dye | 染料 | textile |
| 16 | pottery | 陶器 | craft |
| 17 | porcelain | 普通瓷器 | craft |
| 18 | paper | 紙張 | craft |
| 19 | books | 書籍 | craft |
| 20 | lacquerware | 漆器 | craft |
| 21 | ironware | 鐵器 | metal |
| 22 | copperware | 銅器 | metal |
| 23 | silver | 銀 | metal |
| 24 | saddlery | 馬具 | metal |
| 25 | blades | 刀具 | metal |
| 26 | spice | 香料 | luxury |
| 27 | frankincense | 乳香 | luxury |
| 28 | jewelry | 珠寶 | luxury |
| 29 | ivory | 象牙 | luxury |
| 30 | fur | 皮毛 | luxury |

木材 timber 是一般商品；馬匹不在本表。為把前版 31 項加木材後統一為 30，本次 Candidate Dataset 將「胡椒」暫併入香料、「棉花」暫不獨立成一般商品槽位。這是可替換的資料選擇，不宣稱最終遊戲設定；兩套舊清單只留 sources 與 17，不再並列為有效候選。

高階上等茶、高級絲綢、官窯瓷、特殊貢品屬 V1.5 特殊商品配置，不占這 30 個一般商品槽位。V1 不啟用其交易；馬匹未來用途另定。

## M0 報價與交易預設（全部 Mock）

泉州當地固定報價，僅確認成交時變動庫存；切頁、拖地圖、開 Sheet 不重新抽價。Mock Prices 不代表正式均衡價格。M0 不接動態價格引擎，世界日數固定為第 12 天，除重設外不變動。

- 貨幣採整數；M0 buyPrice= sellPrice=當地展示價，不製造保證獲利示例。
- 城市稅率為 0.05。買入稅=ceil(單價×數量×稅率)，總支出=本金+稅；賣出稅同式，淨收入=本金−稅。
- 平均成本含買入稅：(舊平均成本×舊數量+本次總支出)÷新數量。內部不四捨五入，只在 UI 顯示到小數二位。
- 賣出保留剩餘單位平均成本；清空後移除 CargoItem。當地估值=數量×sellPrice，不含預估賣出稅，標示「稅前估值」。
- 重量、現金與庫存限制由 TradeService 檢查；MAX 買入取庫存、載重與含稅可負擔量之最小值。
- 價量與數量只接受有限正數／正整數；超額不自動成交成別的數量，回傳明確原因並要求重新確認。

這些是可執行 prototype defaults，集中 marketConfig／mockData，未來正式公式替換 service/config 即可，不改 UI。

## 正式 V1 價格引擎位置

保留「基礎價×城市供需×庫存×事件×市場波動」方向，舊係數範圍只在來源追溯。MarketService 之後替換 mock adapter。市場吸收容量、大單分段計價、隨機更新與恢復速度不在 M0。

## 情報差

MarketKnowledge 只存已觀察的 knownPrice、observedDay 與 history。UI 讀取 knowledge selector，不得把外地 MarketItem.currentPrice 作為已知行情。unknown 用 null，不用 0。

M0 現在第 12 天，外地已知價可觀察於第 10／9 天，分別顯示 2／3 天前。PriceTrend 只畫明示已知歷史點；事件／傳聞都是固定展示資料，不影響資產。

## 路線與時間

M0 泉州→琉球、泉州→馬六甲各一條可選航線即可，資料置 routes.ts。RouteService 回傳時間、費用、基本風險與可準備狀態。

「準備前往」只保存 selectedRouteId 與 status=prepared，不扣旅費、不換城市、不增加天數、不清除持貨。再次準備取代舊選擇；取消回 idle。真正出發與抵達屬後續 V1，不能以準備成功冒充航行結算。

完整城市／航線連通性、海陸運輸銜接以 Config Placeholder 留待後續；M0 不阻塞。
