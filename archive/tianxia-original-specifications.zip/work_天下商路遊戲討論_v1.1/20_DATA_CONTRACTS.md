# Data Contracts｜v1.1

**M0 立即使用本契約；不得每個 Vue Component 自行發明格式。**

本文件與 support/contracts.ts 逐字同步。support/mock-fixture.json 為唯一 mock fixture 原始資料，support/mockData.ts 提供 deep-clone factory；這些是交接支援檔，不是前端遊戲已實作。

## 型別

```ts
// v1.1 canonical contracts. Numbers in fixtures are MOCK, not balanced settings.
export type Id = string;
export type DataStatus = 'candidate' | 'mock' | 'placeholder' | 'approved';
export type GoodCategory = 'food' | 'agriculture' | 'textile' | 'craft' | 'metal' | 'luxury';
export type CityType = 'major_port' | 'port' | 'agriculture' | 'craft' | 'metropolis' | 'transit';
export type TradeMode = 'buy' | 'sell';
export interface Good {
  id: Id;
  name: string;
  category: GoodCategory;
  basePrice: number; // >0; mock baseline, not an always-current quote
  weight: number;    // >0, per unit, decimals allowed
  icon: string;      // semantic asset key; resolver must supply fallback
  tier: 'basic' | 'special';
  dataStatus: DataStatus;
}
export interface City {
  id: Id;
  name: string;
  type: CityType;
  position: { x: number; y: number }; // normalized 0..1 on illustrative map
  taxRate: number; // 0..1
  risk: number;    // 0..1; no battle engine implied
  produces: Id[];
  demands: Id[];
  dataStatus: DataStatus;
}
export interface MarketItem {
  cityId: Id;
  goodId: Id;
  buyPrice: number;   // positive integer, before tax
  sellPrice: number;  // positive integer, before tax
  stock: number;     // nonnegative integer
  quotedDay: number; // game day >=1
  priceTrend: 'up' | 'down' | 'flat'; // mock local display, not foreign knowledge
  dataStatus: DataStatus;
}
export interface PriceObservation {
  day: number;       // 1..observedDay
  price: number;     // >0
}
export interface MarketKnowledge {
  cityId: Id;
  goodId: Id;
  knownPrice: number | null;  // null=unknown, never use zero
  observedDay: number | null; // null iff knownPrice=null
  history: PriceObservation[]; // ascending, known observations only
  source: 'visit' | 'rumor' | 'mock';
}
export interface Transport {
  id: Id;
  name: string;
  cargoCapacity: number; // positive weight capacity
  speed: number;         // mock relative index, not a promise of km/h
  rangeDays: number;     // max supported mock route duration
}
export interface Player {
  id: Id;
  name: string;
  money: number; // nonnegative integer
  transport: Transport;
  // No duplicated cargo/currentCityId/currentDay/usedWeight here.
}
export interface CargoItem {
  goodId: Id;
  quantity: number; // positive integer; remove row at zero
  averageCost: number; // >=0; per unit, includes buy tax, unrounded internally
}
export interface Route {
  id: Id;
  fromCityId: Id;
  toCityId: Id;
  mode: 'sea' | 'land';
  travelDays: number; // positive integer
  travelCost: number; // nonnegative integer
  risk: number; // 0..1
  enabled: boolean;
  dataStatus: DataStatus;
}
export interface WorldEvent {
  id: Id;
  title: string;
  description: string;
  type: 'market' | 'risk' | 'rumor';
  cityId?: Id;
  goodId?: Id;
  observedDay: number;
  displayOnly: boolean; // M0=true, never applies an asset effect
}
// V1.5+ contracts: do not instantiate future runtime services in M0.
export interface DevelopmentLevels {
  commercial: number;
  defense: number;
  port: number;
  cultureTechnology: number;
}
export interface SpecialUnlock {
  goodId: Id; // reference to specialGoods, outside 30 basic slots
  commercialLevel: number;
}
export interface CityDevelopment {
  cityId: Id;
  levels: DevelopmentLevels;
  unlockedSpecialGoodIds: Id[];
}
export interface InvestmentRule {
  cityId: Id;
  direction: keyof DevelopmentLevels;
  targetLevel: number;
  cost: number | null; // null=placeholder, not free
  unlocks: SpecialUnlock[];
  dataStatus: DataStatus;
}
export interface Character {
  id: Id;
  name: string;
  role: 'captain' | 'merchant' | 'navigator' | 'guard' | 'accountant' | 'medic';
  portrait: string;
  stats: Record<string, number>;
  trait: string;
  salary: number | null; // null=not set
  fleetId: Id | null;
}
export interface Ship {
  id: Id;
  name: string;
  type: 'merchant' | 'fast' | 'escort';
  cargoCapacity: number;
  speed: number;
  rangeDays: number;
  durability: number;
  defense: number;
  crewRequirement: number;
}
export interface Fleet {
  id: Id;
  name: string;
  flagshipShipId: Id | null;
  shipIds: Id[];
  characterIds: Id[];
  crewCount: number;
}
// Single state owners; assembled snapshots are transient, never a second store.
export interface GameState { currentCityId: Id; currentDay: number }
export interface RouteState { selectedRouteId: Id | null; status: 'idle' | 'prepared' }
export interface TradeSnapshot {
  player: Player;
  game: GameState;
  cargo: CargoItem[];
  market: MarketItem[];
  revision: number; // monotonic across reset as well, rejects stale previews
}
export interface TradeRequest {
  cityId: Id;
  goodId: Id;
  mode: TradeMode;
  quantity: number;
  expectedRevision: number;
}
export type TradeError =
  | 'INVALID_QUANTITY' | 'INVALID_MODE' | 'UNKNOWN_GOOD' | 'NO_QUOTE' | 'WRONG_CITY'
  | 'INSUFFICIENT_STOCK' | 'INSUFFICIENT_FUNDS' | 'OVER_CAPACITY'
  | 'INSUFFICIENT_CARGO' | 'STALE_PREVIEW' | 'BUSY';
export interface TradePreview {
  request: TradeRequest;
  unitPrice: number;
  subtotal: number;
  tax: number;
  cashDelta: number; // buy negative; sell positive
  moneyAfter: number;
  usedWeightAfter: number;
  quantityAfter: number;
  averageCostAfter: number | null; // null if resulting quantity=0
}
export type Result<T, E extends string> =
  | { ok: true; value: T }
  | { ok: false; error: E; message: string };
export interface CargoSummary {
  usedWeight: number;
  capacity: number;
  totalCost: number;
  localValue: number | null; // pre-sale-tax; null if any held good lacks quote
  unrealizedProfit: number | null;
}
export interface TradeServicePort {
  preview(request: TradeRequest): Result<TradePreview, TradeError>;
  buy(request: TradeRequest): Result<TradePreview, TradeError>; // mode must be buy
  sell(request: TradeRequest): Result<TradePreview, TradeError>; // mode must be sell
  maxQuantity(cityId: Id, goodId: Id, mode: TradeMode): number;
  cargoSummary(): CargoSummary;
}
export type RouteError = 'NO_ROUTE' | 'WRONG_ORIGIN' | 'OUT_OF_RANGE' | 'INSUFFICIENT_FUNDS';
export interface RoutePreview { route: Route; canPrepare: boolean; reason: RouteError | null }
export interface RouteServicePort {
  listFrom(cityId: Id): Route[];
  preview(routeId: Id): Result<RoutePreview, RouteError>;
  prepare(routeId: Id): Result<RouteState, RouteError>;
  cancel(): void;
}
export interface PrototypeFixture {
  player: Player;
  game: GameState;
  goods: Good[];
  cities: City[];
  market: MarketItem[];
  knowledge: MarketKnowledge[];
  routes: Route[];
  events: WorldEvent[];
  cargo: CargoItem[];
  routeState: RouteState;
}
```

## 語意與不變量

- ID 穩定、唯一；不使用商品名當 join key。城市／商品／路線外鍵需存在；市場複合 key=cityId:goodId；knowledge 同理，每組最多一筆。
- Good 的 30 個 basic 槽位為 Candidate Dataset；M0 fixture 數值 dataStatus=mock。specialGoods 未來單獨配置，不能與 basic 30 混算。
- 城市位置為0–1示意座標，不是經緯度。taxRate/risk為0–1，金錢、報價、庫存、數量、天數必須有限；狀態與輸入均驗證，不能只靠 TypeScript。
- Player 不含重複 cargo／location；完整 TradeSnapshot 為 command 當下組合的暫時快照，不保存成另一份狀態。
- 平均成本含買入稅、內部保留精度；顯示四捨五入不能寫回成本。capacity／weight 比較可用 config epsilon=1e−9。
- knownPrice=null 時 observedDay=null、history=[]；有報價時 observedDay≤currentDay，history依day遞增且只含實際已知點。Unknown不能畫成0；參考行情不等於當前 MarketItem。
- CityDevelopment、Character、Ship、Fleet 僅是V1.5／V2資料契約，不要求M0建立其runtime store或service。flagshipShipId未來必須是shipIds成員；角色只屬一支艦隊。

## TradeService command

preview：不變更任何狀態；依目前 store 檢查 city／good／quote／quantity／revision，再計算稅、金額、數量、平均成本與重量。

buy／sell：request.mode須符合方法；不符回 INVALID_MODE 並說明模式錯誤。重讀 state，要求 expectedRevision=marketStore.revision；任何價量／資產已變則回 STALE_PREVIEW，UI重新取得摘要並重新確認。

成功 command 需同步更新 playerStore.money、cargoStore.items、marketStore.items.stock，最後增加 revision。處理期間不 await，UI pending guard 防重入；不把普通Pinia連續更新宣稱為資料庫交易。

失敗 command 零副作用。TradePreview 回傳數值是顯示與驗收用結果，不由 UI 再加一次。買入總價與平均成本、賣出淨收入、MAX詳見03。M0 sell不設需求容量上限，只受持貨限制。

reset 必須替換每份 store 資料並提高 revision；不能重設 revision=0 讓重設前舊 request 意外再有效。UI 同時丟棄未成交草稿與pending。

## RouteService command

listFrom：只回 fromCityId相符且enabled的mock路線。
preview：檢查起點、交通工具航程、現金≥travelCost，給 canPrepare/reason；回傳未知路線為 NO_ROUTE。
prepare：重新驗證，成功只修改 routeStore，selectedRouteId與prepared必須同時更新。失敗不覆蓋既有prepared選擇，不扣錢、不改位置／天數／貨物。
cancel：selectedRouteId=null，status=idle。

這是路線準備，不代表已出發。實際航行的資金／時間／Risk Event處理屬後續V1。

## 其他 selector / service

MarketService 只返回當地固定報價；knowledge selector以knownPrice與observedDay顯示age，history不讀全球即時market。
TradeService.cargoSummary 回傳重量、總成本、稅前估值與未實現盈虧；若任一持貨無當地報價則總估值／盈虧=null，UI標示資料不足。

## 修改與驗證

修改契約時同步更新本文件與support/contracts.ts；fixture以JSON一處為準。先型別檢查，再驗外鍵、30商品、20城市、可達路線與03/22算例。這些檢查驗證交接資料，不能代替未來Vue／瀏覽器驗收。
