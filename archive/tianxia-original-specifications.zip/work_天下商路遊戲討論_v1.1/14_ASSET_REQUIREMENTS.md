# Asset Requirements｜v1.1

## Approved Visual Direction Reference

使用者本次已明確正面確認四張圖：世界地圖、泉州市場、貨艙、情報。狀態為 Approved Visual Direction Reference，四張皆為主要視覺方向 Source of Truth，非 Final Pixel-Perfect UI，也不列為缺失素材。

| Reference | 方向用途 | 實作允許 |
|---|---|---|
| 世界地圖 | 海域、城市 marker、狀態列、城市卡 | 調整地圖比例與手機操作 |
| 泉州市場 | 紙面資料、商品列、金框、紅 CTA | 調整字級、列高、交易方式 |
| 貨艙 | 商品資產、成本、容量呈現 | 調整摘要與欄位密度 |
| 情報 | 行情、傳聞與時間的視覺語言 | 調整分區與 Responsive |

本 ZIP 保留參考身分與文字方向；未內嵌二進位圖檔，也未宣稱本輪做過取色／逐像素比對。實作環境已掛載圖檔時直接讀圖；未掛載時先依 11 Suggested Tokens 與 Placeholder Asset 繼續 M0，不能把檔案掛載狀態改寫成「方向未批准」或停工理由。

## V1 資產需求（保留既有數量方向）

| 類別 | 數量 | M0 處理 |
|---|---:|---|
| 主地圖 | 1 | CSS／SVG 示意圖即可，不需要地圖 SDK |
| 大城／中小城 icon | 各3–5 | 可先共用少量輪廓變體 |
| 港口／關卡／村莊 icon | 各1–3 | 按城市類型用 placeholder，不引入新玩法 |
| 玩家標記 | 1–2 | 船形／清楚位置符號 |
| 商品 icon | 30 | candidate ID 對應文字或 SVG placeholder |
| 按鈕／面板／分頁 | 各1套 | 共用元件與 Suggested Tokens |
| 狀態 icon | 6–10 | 金錢／時間／載重／風險 |
| 事件 icon | 8–12 | M0 固定事件卡可用少量 placeholder |
| 城市背景 | 5–8 | 非 M0 必需 |
| 事件插圖 | 5–10 | 非 M0 必需 |
| 商品大圖 | 10–15 | 非 M0 必需 |
| 商人頭像 | 1–3 | 非 M0 必需 |
| 移動動畫 | 1組 | 實際航行延後 |
| 音效 | 少量 | 非 M0 必需 |

V1.5 高階商品／投資圖示；V2 船隻、角色、水手與編成素材，按未來版本處理。

## 檔案與替換規則

asset id 與 good／city ID 穩定對應，資產路徑集中 config。找不到圖時用可見替代符號與名稱，不顯示 broken image。契約的 icon 為語意 key，不保證存在對應 URL。

繁體中文標籤保留可編輯文字，不烘焙入圖；紀錄來源、用途、尺寸、透明需求與授權。使用原圖方向，不逐像素複製。美術替換只修改資產映射／token，不修改 TradeService 或資料主鍵。
