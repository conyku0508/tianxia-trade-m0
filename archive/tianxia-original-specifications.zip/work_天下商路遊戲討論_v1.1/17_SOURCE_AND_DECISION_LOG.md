# Source and Decision Log｜v1.1

有效決策來源：Cony大人2026-10-26 v1.1 Review。本次不推翻遊戲方向，更新阻擋M0的規則、資料與交接。

來源S1–S4的訊息ID與舊D01–D13已原封保留於 [V1_DECISION_LOG_ORIGINAL.md](sources/V1_DECISION_LOG_ORIGINAL.md)，原聊天與兩份歷史提示詞亦保留。這些是歷史證據，不與本頁新決策並行生效。

下列紀錄固定使用 Original→Issue→Decision→Reason→Impact。未來重大變動繼續追加，不覆蓋消除歷史。

## R01

Original：先規劃、等待確認才開發。

↓ Issue：Codex容易停止於提問。

↓ Decision：M0可以立即開始。

↓ Reason：使用者明確授權Prototype。

↓ Impact：更新00–02、06、15、16、21；完整遊戲仍按版本。

## R02

Original：前後Roadmap有兩組分期。

↓ Issue：實作範圍不一致。

↓ Decision：採本次Review的V1/V1.5/V2/V2.5/V3。

↓ Reason：本次Review已定案。

↓ Impact：02及所有未來頁面標示同步。

## R03

Original：商品30/31與木材馬匹引用衝突。

↓ Issue：UI缺穩定資料表。

↓ Decision：單一30槽位V1 Candidate Dataset；保留木材，排除馬匹。

↓ Reason：使用者決策；最終平衡仍可換。

↓ Impact：03／20／22；舊清單僅存sources。

## R04

Original：加入木材後候選超過30。

↓ Issue：需要可執行單一名單。

↓ Decision：胡椒暫併香料，棉花不獨立槽位。

↓ Reason：原型資料選擇，避免同類重疊；非最終正式商品承諾。

↓ Impact：可只改Data/Config；保留30槽位。

## R05

Original：基礎瓷器又需投資解鎖。

↓ Issue：自相矛盾。

↓ Decision：普通基礎品與Lv2–5高階特殊品分開。

↓ Reason：使用者明示解鎖方向。

↓ Impact：04；特殊品不占V1 30一般槽位。

## R06

Original：四張圖列為未取得／缺失。

↓ Issue：未反映使用者已肯定視覺。

↓ Decision：Approved Visual Direction Reference；非逐像素定稿。

↓ Reason：本次Review確立參考狀態。

↓ Impact：11、14、18與所有現行文件；二進位未內嵌如實標註。

## R07

Original：自訂色碼／字級待審。

↓ Issue：可能被當最終設計或阻擋。

↓ Decision：Suggested Tokens；Confirmed Direction與Implementation Approximation分列。

↓ Reason：方向已批准，數值可迭代。

↓ Impact：11；立即可用於M0。

## R08

Original：V1先描述完整Fleet。

↓ Issue：容易過度設計。

↓ Decision：V1商隊／船隊；V2才正式Fleet。

↓ Reason：遵循使用者版本邊界。

↓ Impact：05、07、08、10、12與未來型別範圍。

## R09

Original：經濟／稅／存檔規則未定。

↓ Issue：無法重現UI驗收。

↓ Decision：M0固定mock價、含稅成本、memory-only、prepared不扣款不推時。

↓ Reason：提供可執行測試預設；非最終平衡。

↓ Impact：03、09、20、22；Service可替換。

## R10

Original：僅有元件名稱，無共享契約。

↓ Issue：各頁可能各算資產或硬編。

↓ Decision：Data/UI/Logic分離、SSOT、共用UI、統一型別。

↓ Reason：控制修改範圍與狀態一致。

↓ Impact：12、20、21與support。

## R11

Original：缺乏畫面排列與實作分期。

↓ Issue：Codex仍需重規劃。

↓ Decision：新增10頁wireframe、M0-A–G與驗收fixture。

↓ Reason：讓M0可直接執行。

↓ Impact：19、21、22。

## R12

Original：原型準備出航與實際航行可能混用。

↓ Issue：測試終點不清楚。

↓ Decision：M0只做到prepared；Sailing等只保留wireframe。

↓ Reason：使用者M0目標止於準備下一城。

↓ Impact：08–10、19–22。


## 仍是Placeholder，不構成M0阻擋

經濟平衡、正式價格與係數、候選最終商品選擇、投資金額／曲線、角色公式、艦隊合成、完整航線／海陸銜接、最終asset與design token。使用03、11、20、22預設繼續開發。

## 未來真的需要停止處理的條件

架構衝突、不可逆資料操作、需刪除既有功能、核心玩法重大改變。其他合理placeholder自行記錄後執行。
