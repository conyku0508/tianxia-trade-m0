# IA / Sitemap｜v1.1

M0 直接進 /map 與泉州起始狀態；Splash 與正式新遊戲流程不是驗收依賴。五個主入口固定。

```text
AppShell
├─ Page /map                世界地圖
│  ├─ City Bottom Sheet     點泉州／其他城市
│  │  ├─ 本城 → /market
│  │  └─ 外地 → /route?routeId=...
│  └─ Route Summary Drawer  時間／費用／風險
├─ Page /market             僅當前城市市場
│  ├─ Goods Detail / Trade Bottom Sheet
│  └─ Confirm Trade Modal
├─ Page /cargo              持貨／成本／稅前估值／載重
├─ Page /intelligence       舊行情／傳聞／事件／已知趨勢
│  └─ 有直接航線 → /route?routeId=...
├─ Page /menu               原型說明／重設測試資料
└─ Page /route              已有玩法中的路線規劃，非第六個導覽入口
   ├─ Route Summary Drawer
   └─ 準備前往 → prepared 狀態
```

## 路由與狀態規則

底部五入口為 /map、/market、/cargo、/intelligence、/menu；/route 從城市、情報或地圖內按鈕進入。Route 頁屬地圖領域，底部選中「地圖」。

City Detail 是暫時 Sheet，不強迫每點一次城市就全螢幕跳頁。交易數量在 Trade Sheet 編輯，Confirm Trade Modal 僅摘要／確認／取消，不在每一筆商品開新 Page。

Route 詳細比較可用 Page；單一路線概要用 Drawer，避免同一資訊重複堆疊。手機 Modal 開啟時停用底層互動與捲動；Drawer 關閉回原頁。

頁面切換保留資產與交易結果，關閉未成交草稿不改狀態。所有市場入口讀 gameStore.currentCityId，不會因選過外地卡就切到外地交易。

## 後續入口（不在 M0 顯示成可用功能）

V1.5 城市→City Investment Page。V2 船隊入口→Fleet Page→Ship／Character；城市→Recruitment。不加第六個底部入口，不在 V1 建完整 Fleet Center。
