# CHANGELOG｜v1.1

日期：2026-10-26。結果：**M0 Mobile Frontend Prototype Ready for Codex**。

## 修改了哪些文件

| 文件 | 修改 |
|---|---|
| 00 | 新索引、閱讀順序、有效規格與歷史來源區別、M0 Ready |
| 01–02 | 保留核心定位，依Review定案分期，明確M0與完整V1差異 |
| 03 | 單一30槽位Candidate Dataset、木材／馬匹、固定mock報價／交易／準備路線規則 |
| 04 | 基礎普通商品與Lv2–5高階特殊商品分離，舊門檻退役 |
| 05 | V1商隊／船隊，正式Fleet留V2 |
| 06–08 | 即刻開發、技術、三層、路由、Page／Sheet／Modal與各Screen階段 |
| 09–10 | 可重現購買／貨艙／情報／route流程、狀態與錯誤處理 |
| 11 | Approved Direction為權威、Suggested Tokens，完整semantic狀態 |
| 12 | Data／UI／Logic、SSOT、可共用元件、修改隔離與目錄 |
| 13–14 | 可立即使用RWD、四張已批准視覺參考、placeholder替換 |
| 15 | 改為可直接貼給Codex的M0開發入口；先列修改層級與檔案後執行 |
| 16 | Work維護提示詞同步，不再要求先確認數字 |
| 17 | 保留原log原文，追加Original→Issue→Decision→Reason→Impact |
| 18 | 如實標記包裝／雲端／參考圖二進位與原型實作狀態 |
| MANIFEST.json | 重建v1.1檔案清單、大小、SHA-256與驗證摘要 |

## 新增文件

- 19_UI_WIREFRAMES.md：10畫面ASCII wireframe，標記M0／未來版本。
- 20_DATA_CONTRACTS.md：Good、City、MarketItem、MarketKnowledge、Player、CargoItem、Route、WorldEvent、CityDevelopment、Character、Ship、Fleet及支援契約。
- 21_FRONTEND_IMPLEMENTATION_PLAN.md：M0-A至G，目標、預計檔案、順序、完成條件。
- 22_M0_FIXTURES_AND_ACCEPTANCE.md：額外補強的mock資料／算例與驗收。
- support/contracts.ts、mock-fixture.json、mockData.ts、validate-fixture.mjs：共享型別、單一fixture、工廠與驗證工具。
- sources/V1_DECISION_LOG_ORIGINAL.md：原v1決策原文保存。
- 本CHANGELOG與VALIDATION_REPORT。

## 解決的矛盾

1. 「先等確認」→M0立即可做；完整遊戲引擎仍後續接。
2. 30／31兩套→單一30槽位；木材保留、馬匹排除；Candidate暫將胡椒併香料、棉花不獨立占槽，可後續只改Data。
3. 泉州已有瓷器卻需解鎖→普通瓷器已售，投資開高階特殊品；不混一般30槽位。
4. 四圖缺件標記→Approved Visual Direction Reference；本ZIP未內嵌二進位是交付事實，不是方向未批准。
5. 自訂色碼似定案→Suggested Tokens／Implementation Approximation。
6. V1完整Fleet→商隊／船隊；Fleet runtime留V2。
7. 資產與資料各頁自行算→統一契約、SSOT與Service；UI不存第二份資產。
8. 路線準備與出航混淆→prepared不扣款、不換城、不推時間。

## 仍是Placeholder

正式經濟平衡、商品正式價格／最終品項、投資費用與曲線、角色能力／薪資、艦隊數值、完整海陸路線與城市細項、最終資產及token精確值。M0有可用Mock Config，不因以上事項停止。

## Codex現在可以做

AppShell、World Map、City Bottom Sheet、Market買賣、Cargo、Intelligence、Route Planning，完成主流程並依22驗收。每次先分類Data／UI／Logic，列預計檔案，隨即執行。

## 不可提前開發

M0不建完整經濟引擎、投資結算、特殊商品實際交易、角色招募／水手薪資、旗艦多船／Fleet、第二商隊／自動貿易、分店商會影響力、戰爭／外交／海戰／大型RPG。Sailing／存檔／PWA離線不作M0必要交付。海盜只保留Risk Event方向。

## 檢查與限制

檔案、連結、歷史保留、契約同步、fixture與算例、ZIP完整性均在VALIDATION_REPORT記錄。規格Ready不代表Vue已實作；不宣稱本輪完成UI或瀏覽器驗收。
