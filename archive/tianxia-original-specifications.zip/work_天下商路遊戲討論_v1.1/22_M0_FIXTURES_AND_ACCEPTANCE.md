# M0 Mock Fixture 與 Acceptance｜v1.1

所有數字均為Mock Data／Config Placeholder，可直接用來開發與驗收，不是正式經濟設定。

## 唯一資料來源

support/mock-fixture.json：20城、30 basic商品、泉州30筆報價、3筆外地knowledge、2條航線、2個展示事件、初始玩家／空貨艙。

support/mockData.ts每次deep clone提供新狀態；不要直接修改JSON匯入物件。support/contracts.ts與20一致。Codex可把fixture分至data/*.ts，但不得保留兩份會分歧的可編輯數值來源。

所有城市的mock type／座標是為原型展示，不是正式城市考據與平衡。主要可操作路線只需泉州起點，其他城不假裝全部已連通。

重新檢查交接資料可執行：

```sh
node support/validate-fixture.mjs
```

需要Node 24+；此工具驗證契約語法、資料參照與算例，不執行尚不存在的TradeService或Vue畫面。

## 初始狀態

| 項目 | 值 |
|---|---|
| currentCityId / currentDay | quanzhou / 12 |
| money | 5000 |
| transport | 小型商船；cargoCapacity=100、speed=1、rangeDays=20 |
| cargo / route | []；selectedRouteId=null、status=idle |
| market revision | store初始1；每次交易／重設遞增，不在各頁重設 |
| 泉州茶葉 | buyPrice=360、sellPrice=360、stock=20、weight=1 |
| 泉州絲綢／瓷器／香料 | 850／520／950，重量1／3／1 |
| 泉州木材／稻米 | 120／80，重量7／4 |
| 其他商品 | basePrice=100+槽位×10，weight=2，stock=20 |
| 所有mock報價 | 依basePrice，稅前buy=sell；quotedDay=12 |
| 泉州稅率 | 0.05 |
| Malacca known tea | 500，第10天觀察，歷史day8=470、day10=500 |
| Ryukyu known porcelain | 680，第9天觀察，歷史day7=650、day9=680 |
| Aden spice | knownPrice=null、observedDay=null、history=[] |
| quanzhou_ryukyu | 3天／120／risk .08 |
| quanzhou_malacca | 12天／480／risk .18 |

## 必測流程

| Case | 操作 | 預期 |
|---|---|---|
| A01 | Map點泉州→Sheet→Market | currentCity不變，顯示本地30商品與狀態 |
| A02 | 買茶2，先取消確認 | money5000、cargo空、stock20 |
| A03 | 再買茶2並確認 | money4244、茶2、avg378、stock18、weight2 |
| A04 | 轉Cargo／Header／Market | 同步持有2，成本756、稅前估值720、盈虧−36 |
| A05 | 看Intelligence | 馬六甲2天前、琉球3天前；亞丁未知不是0 |
| A06 | 選琉球→準備 | route prepared；money4244、泉州、day12、茶2全部不變 |
| A07 | 取消準備 | route idle、selectedRouteId=null，資產不變 |
| A08 | 重設後買茶2，再賣茶1 | 現金4586、茶1、avg378、stock19、weight1 |
| A09 | 全新fixture MAX買茶 | 13單位；本金4680+稅234=4914；剩86 |
| A10 | 全新fixture MAX買木材 | 14單位；受重量98≤100限制 |
| A11 | 買0／負數／小數／NaN／超庫存 | 拒絕；每項確認無資產副作用 |
| A12 | 餘額不足／超重／超額賣 | 明確原因；不把數量自動偷偷縮小 |
| A13 | 連點確認／舊revision | pending防重入；舊request回STALE_PREVIEW，不能再成交 |
| A14 | 取消Sheet／切五入口／重開城市 | 不清資產、不抽新價、不改所在地 |
| A15 | 重設後沿用舊request | revision已提高，舊request失效；route/UI草稿清空 |
| A16 | money不足旅費或range不足 | RouteService拒絕準備，不改資產與既有prepared |
| A17 | 刷新頁面 | memory-only重回fixture；UI／README明示，不稱存檔失敗 |

超額測試可注入明確fixture變體（如money=0、capacity=1），不修改正式資料或在UI硬編測試條件。Chart只畫known observations，不能因資料稀疏補假即時曲線。

## Responsive／裝置驗收

360×800、390×844、430×932、768×1024、1024×768、1440×900各跑關鍵頁。檢查底部遮擋、長名稱、大金額、鍵盤數量輸入、MAX、Modal取消、Sheet內捲動、地圖選點與縮放。

Page／Drawer／Modal的焦點與返回路徑必驗；Header與Cargo數值同步不靠重載頁面。桌面須有內容重排，不僅等比放大。

## Done與真實回報

Codex完成M0須提供啟動方式、主要流程、型別／build／service測試與瀏覽器驗收結果，分別標記通過、未執行或受限。本文件包僅驗證資料與規格，沒有已建立Vue App或實機結果。
