# Screen Specification｜v1.1

實作級配置以本文件、19 線框、20 契約、22 fixture 為準；視覺方向以四張 Approved Visual Direction Reference 為準。Suggested Tokens 可直接作近似實作，不需等待最終數值。

## 全域 AppShell

TopStatusBar：城市、天數、現金、已用／最大載重；貨艙摘要連 /cargo，不顯示 V2 Fleet 入口。底部五入口固定。內容區可捲動，留 Header、Navigation、安全區空間；最後一列與 CTA 可完整顯示。

顯示「M0 原型／模擬資料」標記。狀態：Loading、Empty、Unknown、Locked、Error、Disabled 明確區分。資產全部來自 store／service selector，UI 不自行加總或扣款。

## S02 World Map（M0 必須）

Header：全域狀態。Content：示意海域底圖、20 城 marker、泉州玩家位置、兩條 active mock 路線；可拖曳／縮放。其餘城市可點摘要，但沒有路線不提供可準備操作。

點城市開 Sheet；被選中 marker 有 Selected 狀態。圖上名稱與基本地理不是行情；不洩漏外地即時價格。對裝置支援問題可先提供 zoom buttons 配合拖曳，不需要地圖 SDK。

## S03 City Bottom Sheet（M0 必須）

城名／類型→主要出產與需求→稅率／風險／情報時間→CTA。泉州 CTA「進入市場」，外地有 active route 則「查看航線」，否則「暫無原型航線」。城市發展與招募標示後續版本，不新增可執行按鈕。

手機半屏／可展開，最大高度扣除安全區；內文捲動，CTA 底部可見。關閉回地圖。Desktop 用側 Drawer，不強制全螢幕。

## S04 Market（M0 必須）

Header／City Hero：泉州、市場稅率、現金、剩餘載重。Filter：全部及分類，由 goods category 產生。Goods List：icon、名稱、buy/sellPrice、庫存、持有、平均成本與 mock 價格趨勢。欄位不足時主次兩行，不縮成難讀小字。

Trade Bottom Sheet：模式、數量 +/−／整數輸入／MAX、單價、稅、總額、交易後現金與載重；總額由 TradeService preview 回傳。Primary「確認摘要」開 Confirm Trade Modal；Modal「確認買入／賣出」「取消」。

處理缺貨、沒有持貨、餘額不足、超重、無效數量與 pending。Confirm 期間禁重入。Goods Detail 可與 Trade Sheet 共用內容，禁止兩層重複商品 Sheet。

## S05 Cargo（M0 必須）

Header：載重／最大容量與 ProgressBar。內容：商品、數量、平均成本、當地稅前估值、重量、未實現盈虧。底部或頂部摘要：總成本、稅前估值、未實現盈虧，均由 service selector 回傳。

Empty：說明尚無貨物＋前往市場。持貨只引用 cargoStore.items；切頁不清除。出場商品不存在報價時 value=null 並顯示無報價，不以0代替未知。

## S06 Intelligence（M0 必須）

Known Price：城市、商品、knownPrice、observedDay 及相對時間。Rumor：文字傳聞、時間。World Event：固定事件卡，明示模擬展示。PriceTrend：已知歷史點，用 SVG 或 Chart.js，不畫未知期間假資料。

只讀 knowledge selector，不讀外地 marketStore 即時值。未知顯示「尚無情報」；knownPrice=null 時不畫成0。可對有 active route 的城市開路線頁。

## S07 Route Planning（M0 必須）

起點固定 gameStore.currentCityId；可選琉球／馬六甲路線。卡片顯示目的城、mock 所需日數、費用、基本風險、可用性。Drawer 顯示單一路線摘要；取消不改旅程。

Primary「準備前往」→routeStore.selectedRouteId + status=prepared。下方顯示「已準備：泉州→琉球。原型不扣費／不推進時間」。無資金或超出 transport.rangeDays 顯示不可準備原因。

離開頁面可保留 prepared；選另一條再準備取代；「取消準備」清空 selection、回 idle。不啟動倒數或自動跳轉到 Sailing。

## /menu（M0 必須容器）

顯示版本、模擬資料說明、玩家摘要與「重設原型資料」。重設經 ConfirmDialog 後重建所有 store，清除 route selection、modal 草稿；不呼叫正式 SaveService。M0 預設 memory-only，重新載入回 fixture，README 及選單明示。

## 既有其餘 Screen 保留

| Screen | 配置／操作 | 階段 |
|---|---|---|
| S01 Splash | 名稱、繼續／新遊戲／設定 | 後續 V1，M0 可直接進地圖 |
| S08 Sailing | 起終點、航行進度、剩餘日數、事件區 | 後續 V1，見 W07 |
| S09 Random Event | icon、標題、影響、確認 Modal | V1 Risk Event；M0 只展示事件卡 |
| S10 Investment | 城市、四方向、等級、成本、特殊商品階段 | V1.5，W08 |
| S11 Fleet | 旗艦／商船／護衛、人物、水手、貨艙摘要 | V2，W09 |
| S12 Ship Detail | Type、Cargo、Speed、Range、Durability、Defense、Crew | V2 Drawer |
| S13 Character | 列表、能力、特性、薪資、指派 | V2 Page＋詳情 Drawer |
| S14 Recruitment | 城市、候選、薪資、角色詳情、雇用摘要 | V2，W10 |
| S15 Player | 名稱、資金、位置、資產摘要 | M0 /menu 簡版，未加等級聲望 |
| S16 Settings | 實際可用選項再建立控制 | 後續；M0 不做假開關 |
| S17 Save / Load | 保存狀態、手動存／讀與失敗訊息 | 後續 V1，非 M0 前置 |

未來頁面可以靜態稿展示，但不得為了交齊畫面而建立未授權經濟引擎、FleetService 或 RecruitmentService。
