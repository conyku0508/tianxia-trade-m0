# Screen Map｜v1.1

17 種原畫面保留，M0 實作邊界明確如下。Screen ID 與 19 wireframe ID 各自獨立；19 的 W01–W10 對應本表名稱。

| ID | 畫面 | 層級／入口 | 本次 M0 |
|---|---|---|---|
| S01 | Splash / Main Menu | Page／啟動 | 非必要；直接 /map 即可 |
| S02 | World Map | Page /map | 必須 |
| S03 | City Detail | Bottom Sheet／選城 | 必須 |
| S04 | Market | Page /market + Trade Sheet + Confirm Modal | 必須；買賣 mock |
| S05 | Cargo | Page /cargo | 必須 |
| S06 | Intelligence | Page /intelligence | 必須 |
| S07 | Route Planning | Page /route + Summary Drawer | 必須；結束於 prepared |
| S08 | Sailing | Page／未來實際出發 | wireframe；非 M0 必須 |
| S09 | Random Event | Modal | M0 情報可展示事件卡；不要求觸發引擎 |
| S10 | City Investment | Page／城市 | V1.5 wireframe |
| S11 | Fleet | Page／未來船隊入口 | V2 wireframe |
| S12 | Ship Detail | Drawer／Fleet | V2 規格保留 |
| S13 | Character | Page／詳情 Drawer | V2 規格保留 |
| S14 | Recruitment | Page／城市 | V2 wireframe |
| S15 | Player Profile | /menu 內摘要 | M0 僅顯示原型玩家 |
| S16 | Settings | /menu 內預留 | 不做無實際作用開關 |
| S17 | Save / Load | Page／選單 | M0 不必實作；預設記憶體 |

附屬 /menu 為必要第五入口，顯示原型版本與重設 fixture。關閉交易草稿、Modal、Route Drawer 回到原頁，不新增 Page。

M0 航行天數固定；「準備前往」不觸發 Sailing、不扣費、不換城市。可在下一里程碑接時間推進，而不用變更 UI 契約。
