# v1.1 Validation Report

日期：2026-10-26（Asia/Taipei）。

## 實際通過

- 原ZIP可讀且完整；原包保持不變。
- 原19份主要Markdown全部已更新；00–22共23份編號文件齊全。
- 10個wireframe、M0-A至G七階段、12個必要Data Interfaces存在。
- 現行Markdown相對連結有效、code fences成對、文件非空。
- 原三份來源文件逐byte與原ZIP相同；舊Decision Log另存原文也逐byte相同。
- 單一Candidate商品表30筆，ID與名稱逐筆對上fixture；城市20筆；木材存在、馬匹不在一般資料。
- 20契約code block與support/contracts.ts一致；Node24 stripTypeScriptTypes語法解析通過。
- fixture的唯一ID、城市／商品外鍵、市場複合key、舊情報／未知值、歷史時間、航線、展示事件檢查通過。
- 依mock參數核算買茶2、賣茶1、MAX茶13、木材載重上限14及路線3天／120／8%算例通過。
- 確認現行規格的M0可立即開發、Approved Visual Direction、三層／SSOT與prepared邊界一致；舊等待規則只作歷史紀錄。
- 最終封裝檢查ZIP CRC、檔案數與manifest SHA-256逐檔一致。

## 檢查範圍

Node語法解析不是完整tsc型別檢查；算例是資料與規格oracle，不是執行尚未實作的TradeService。未建立Vue App，未執行其build、瀏覽器、手機裝置、正式經濟或服務行為測試。22提供後續Codex的必要驗收案例。

四張圖依使用者Review確立Approved Visual Direction Reference。本包未內嵌圖檔，本次沒有原圖取色或逐像素視覺驗證。這不影響使用Suggested Tokens與Placeholder Assets開發M0。

重新檢查fixture可使用：node support/validate-fixture.mjs（Node24+）。
