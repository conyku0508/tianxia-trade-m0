# Frontend Overview｜v1.1

**M0 Mobile Frontend Prototype 可以立即開始。**

## 技術與交付

Vue 3、Vite、TypeScript、Pinia、Vue Router、Tailwind CSS。以目前穩定且互相相容版本初始化並提交 lockfile；不要因未鎖舊版而等待。Chart.js 非必要，PriceTrend 可用簡單 SVG 表示已知 mock 歷史。

必要成果為可啟動前端、README、mock fixture 與可操作主流程。原型在每頁提供「M0 原型／模擬資料」可見標記；不宣稱模擬數值已平衡。

## 三層分離

Data / Config：城市、商品、航線、事件、未來投資／解鎖與遊戲數值。

UI / Presentation：畫面與版面、共用元件、Modal／Sheet、Responsive、顯示／Selected／Active／Hover／動畫與輸入意圖。

Game Logic / Service：價格、資產與載重、交易驗證、路線計算、投資解鎖、存檔。M0 只實作必要的 Mock MarketService、TradeService、RouteService；未來 service 按版本加入。

Pinia 為三層間的狀態來源。資料定義見 20，目錄／職責見 12，執行順序見 21。

## 共同體驗

五個入口地圖／市場／貨艙／情報／選單；390×844 優先。Header、Market、Cargo 使用相同 player/cargo/game/market store，不複製資產狀態。

Page：Map、Market、Cargo、Intelligence，Fleet 留 V2。
Bottom Sheet / Drawer：City Detail、Goods Detail、Route Summary。
Modal：Confirm Trade、Random Event、Warning、Save Confirmation（後兩者按實際功能出現）。

Mock Data、Placeholder Asset、Suggested Tokens 可以直接採用。經濟、角色、投資、艦隊、正式商品與原圖檔案掛載不構成 M0 阻擋。

只有架構衝突、資料不可逆、需刪除既有功能或大幅改變核心玩法時才暫停受影響工作並提出問題；其餘先列修改檔案後繼續實作。
