# Design System｜v1.1

## 視覺權威與狀態

四張「世界地圖／泉州市場／貨艙／情報」均為 **Approved Visual Direction Reference**，使用者本次 Review 明確確認。它們是視覺語言的主要 Source of Truth，非 Final Pixel-Perfect UI。

Confirmed Direction：復古策略、明亮手繪、Pixel Remaster、東方航海、深墨綠／深藍、金框、米白紙面、紅色 CTA、清楚商品 icon、資訊多但可讀。

Implementation Approximation：下表所有 hex、尺寸、shadow、border、字型堆疊與間距皆為 **Suggested Tokens**，可立即用於 M0；未經原圖取色或逐像素量測，不宣稱為最終定案。看到參考圖時以其方向調整 token，不能因此延後 M0。

## Semantic Tokens

| 分類 | Confirmed Direction | Suggested Token / Implementation Approximation |
|---|---|---|
| Primary Colors | 深墨綠／深藍的航海策略底色 | primary=#123C36；navy=#152D45 |
| Secondary Colors | 金色與暖紙色陪襯 | secondary=#BA9855 |
| Background | 深色主場景、明亮資料前景 | background=#102D2A |
| Panel | 米白內容、層級清楚的框 | panel=#F4E8CF；radius=6px |
| Gold Border | 細金框，不犧牲閱讀 | border=#BA9855；1px solid |
| Red CTA | 重要操作紅色 | cta=#9F3731；text=#FFFFFF |
| Information Paper Background | 暖米白紙張區 | paper=#F4E8CF；ink=#252B2A |
| Positive | 獲益／有利需文字與符號，未指定色碼 | positive=#256846；「＋／上升」 |
| Negative | 損失／不利需文字與符號 | negative=#A33232；「−／下降」 |
| Locked | 鎖定與條件可辨，未指定色碼 | locked=#68655E；鎖頭＋條件 |
| Warning | 風險／過期情報／限制需明示 | warning=#805712；警示 icon |
| Selected | 選中路線／marker 有明顯框與標記 | selected=#E9CB82；2px outline |

Positive/Negative/Locked/Warning/Selected 的語意是本次實作規格，具體色碼並非由原圖確認。文字對比需在 M0 驗收實測，不能宣稱目前已通過。

## Typography / Border / Panel / Button / Shadow

- Typography Suggested：繁中可讀系統字型堆疊；body 16px/1.5、secondary 14px、title 20–24px。數字 tabular-nums；標題可有復古氣質，內文不硬用難辨識點陣字。
- Border Suggested：面板細金框1px，選中2px；不在每列堆厚框。
- Panel Suggested：6px 圓角，內距16px；紋理低對比，不遮文字。
- Button Suggested：Primary 紅底白字；Secondary 紙底墨字描邊；Disabled 明確理由。touch target≥44×44px。
- Shadow Suggested：0 4px 12px rgba(0,0,0,.20)，只用於浮層，不當所有卡片預設。
- Spacing Suggested：4／8／12／16／24px；桌面可增容器留白，不整體放大字級。

## 共用元件與狀態

PrimaryButton、IconButton、GamePanel、GoodsRow、CharacterCard、ShipCard、ProgressBar、Modal、BottomSheet、ConfirmDialog、Toast 共用，不逐頁複製。元件只顯示資料與互動意圖。

Navigation 五入口有文字與 icon；Selected 不只換色。趨勢與盈虧同時有符號和數值。Locked 顯示條件，Unknown 顯示未知，Empty 顯示尚無項目，不能混為灰色空白。

四張圖的資訊配置可因手機可讀性、Responsive、操作體驗或技術限制調整。不要做 SaaS Dashboard、Cyberpunk、3D 寫實或過量插圖。M0 先使用可辨識 placeholder，再換素材。
