import type { PrototypeFixture } from './contracts';
import fixture from './mock-fixture.json';
// One fixture source. A fresh deep clone is required for every reset/store initialization.
// JSON uses a typed boundary; run validate-fixture.mjs for values and references.
// This assertion is not a substitute for runtime validation or future tsc checking.
const checkedFixture = fixture as PrototypeFixture;
export function createMockFixture(): PrototypeFixture {
  return structuredClone(checkedFixture);
}
