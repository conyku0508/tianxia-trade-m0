# work_天下商路遊戲討論｜v1.1

日期：2026-10-26（Asia/Taipei）。

**M0 Mobile Frontend Prototype Ready for Codex。Frontend Prototype 可以立即開始。**

## 開始方式

把 [15_CODEX_FRONTEND_HANDOFF.md](15_CODEX_FRONTEND_HANDOFF.md) 交給Codex，直接依 [21實作計畫](21_FRONTEND_IMPLEMENTATION_PLAN.md) 執行，不以正式數值／資料未定為由再次停在等待。

必達：World Map→點泉州→City Bottom Sheet→Market→Buy→Cargo→Intelligence→Route Planning→Prepared。

技術：Vue3／Vite／TypeScript／Pinia／Vue Router／Tailwind；Mock Data、Placeholder Asset、Config。M0不需要完整經濟引擎、正式資料、真實航行或Fleet系統。

## 權威與標記

1. 2026-10-26使用者Review是本次修正權威，已記錄於17；取代v1被更新的等待規則。
2. 四張圖是Approved Visual Direction Reference／視覺方向Source of Truth，非Final Pixel-Perfect UI。
3. 19／20／21／22是M0線框、契約、執行與驗收依據；03／10／11／12／13補足細節。
4. V1 Candidate Dataset＝唯一30一般商品槽位，可換最終品項；Mock Data／Config Placeholder不是正式經濟平衡；Suggested Tokens是Implementation Approximation。
5. sources全部唯讀歷史資料，與現行規格衝突時不能執行舊規則。

## 文件索引

| 文件 | 用途 |
|---|---|
| [00_PROJECT_INDEX.md](00_PROJECT_INDEX.md) | 入口與權威順序 |
| [01_GAME_OVERVIEW.md](01_GAME_OVERVIEW.md) | 定位與M0目標 |
| [02_ROADMAP.md](02_ROADMAP.md) | M0與V1–V3邊界 |
| [03_WORLD_AND_ECONOMY.md](03_WORLD_AND_ECONOMY.md) | 單一30槽位資料與Mock經濟規則 |
| [04_CITY_INVESTMENT.md](04_CITY_INVESTMENT.md) | 基礎／高階商品分離 |
| [05_FLEET_AND_CHARACTERS.md](05_FLEET_AND_CHARACTERS.md) | V1商隊／V2艦隊 |
| [06_FRONTEND_OVERVIEW.md](06_FRONTEND_OVERVIEW.md) | 前端目標與三層概覽 |
| [07_INFORMATION_ARCHITECTURE.md](07_INFORMATION_ARCHITECTURE.md) | 五入口／Page／Sheet／Modal |
| [08_SCREEN_MAP.md](08_SCREEN_MAP.md) | 17種Screen與M0範圍 |
| [09_USER_FLOW.md](09_USER_FLOW.md) | 主流程與可重現算例 |
| [10_SCREEN_SPEC.md](10_SCREEN_SPEC.md) | 每頁配置與狀態 |
| [11_DESIGN_SYSTEM.md](11_DESIGN_SYSTEM.md) | Confirmed Direction與Suggested Tokens |
| [12_COMPONENT_ARCHITECTURE.md](12_COMPONENT_ARCHITECTURE.md) | 三層／SSOT／共用／修改隔離 |
| [13_RESPONSIVE_SPEC.md](13_RESPONSIVE_SPEC.md) | 可立即使用的RWD規則 |
| [14_ASSET_REQUIREMENTS.md](14_ASSET_REQUIREMENTS.md) | 已批准視覺參考與資產替換 |
| [15_CODEX_FRONTEND_HANDOFF.md](15_CODEX_FRONTEND_HANDOFF.md) | 可直接貼給Codex的開發入口 |
| [16_WORK_MASTER_PROMPT.md](16_WORK_MASTER_PROMPT.md) | 規格維護與協作提示詞 |
| [17_SOURCE_AND_DECISION_LOG.md](17_SOURCE_AND_DECISION_LOG.md) | 歷史沿革與本次決策 |
| [18_IMPORT_STATUS.md](18_IMPORT_STATUS.md) | 本機與雲端狀態 |
| [19_UI_WIREFRAMES.md](19_UI_WIREFRAMES.md) | 10頁ASCII線框 |
| [20_DATA_CONTRACTS.md](20_DATA_CONTRACTS.md) | 共用TypeScript型別與service契約 |
| [21_FRONTEND_IMPLEMENTATION_PLAN.md](21_FRONTEND_IMPLEMENTATION_PLAN.md) | M0-A至M0-G執行計畫 |
| [22_M0_FIXTURES_AND_ACCEPTANCE.md](22_M0_FIXTURES_AND_ACCEPTANCE.md) | Mock fixture與可驗收結果 |

## 支援檔與報告

- [CHANGELOG.md](CHANGELOG.md)：改動、解決矛盾、placeholder與開發邊界。
- [support/contracts.ts](support/contracts.ts)：與20逐字一致的共用型別。
- [support/mock-fixture.json](support/mock-fixture.json)：唯一可重現mock資料來源。
- [support/mockData.ts](support/mockData.ts)：初始化deep clone。
- [support/validate-fixture.mjs](support/validate-fixture.mjs)：fixture與契約語法／算例檢查。
- [VALIDATION_REPORT.md](VALIDATION_REPORT.md)：本包實際檢查範圍。
- [MANIFEST.json](MANIFEST.json)：所有payload檔案大小與SHA-256；manifest本身不自我雜湊。

原聊天、完整Codex／Work提示詞與原v1 Decision Log均保留sources。原ZIP另行保留；本次沒有建立Vue原型或更新雲端聊天。

只在架構衝突、不可逆資料、刪除既有功能或核心玩法重大改變時停下提出問題，其餘合理placeholder持續實作。
