# 城市投資與高階特殊商品｜v1.1

V1.5 系統，M0 僅提供 wireframe／資料契約，不建立投資結算。

## 基礎商品與特殊商品分離

泉州基礎可交易：普通瓷器 porcelain、普通茶葉 tea、普通絲綢 silk。它們不需要投資才出現。

| 商業發展階段 | 高階特殊商品 | 建議 stable id |
|---|---|---|
| Lv.2 | 上等茶 | superior_tea |
| Lv.3 | 高級絲綢 | premium_silk |
| Lv.4 | 官窯瓷 | imperial_porcelain |
| Lv.5 | 特殊貢品 | tribute_goods |

發展階段與基本／高階分離是本次 Review 的有效方向；投資金額、升級曲線、各城差異、特殊商品報價為 Config Placeholder。舊 20/40/60/80/100 與 30/50/70/90 商業度門檻已退役，僅保留歷史。

特殊商品是後續經濟成長、城市養成、商品收集目標，不是投資後憑空新增原本不存在的基礎瓷器。特殊商品配置與 V1 的 30 一般商品槽位分開。

## 四方向

| 方向 | 後續效果方向 | 資料／邏輯歸屬 |
|---|---|---|
| Commercial 商業 | 發展、市場容量、高階商品 | investment.ts + InvestmentService |
| Defense 防衛 | 降低 Risk Event 影響 | investment.ts + InvestmentService |
| Port 港口 | 停靠、航程相關成長 | investment.ts + InvestmentService |
| Culture / Technology | 特殊發展與未來人才 | Config Placeholder |

投資費用、升級條件、unlockGoodIds 置 Data/Config；判定置 InvestmentService，不在 Vue component。未達條件顯示鎖定、條件與下一階段獎勵；視覺用 Locked token。

## 後續流程

城市→投資→選方向→預覽成本／效果→確認→升級／解鎖→市場查看高階品。M0 可展示靜態 wireframe，禁止按下按鈕卻假裝完成經濟結果；這不影響 M0 交易與路線流程。
