# 商隊／船隊與未來艦隊｜v1.1

## V1 / M0 使用商隊／船隊

只描述目前交通工具、貨艙、速度、航程、載重、航行時間、基本風險。Player.transport 與 Cargo 足夠，不建立 Fleet store、旗艦槽位、多船編成、薪資模擬或 recruitment service。

M0 mock 起點為泉州、小型商船，數值置 Config；Header 的載重狀態只連至貨艙，不把 V2 Fleet Center 提前顯示。

## V2 正式艦隊

V2 才引入旗艦、商船、護衛船、船長、商務官、領航員、護衛、會計／醫官、水手與編成。20 的 Character、Ship、Fleet 是未來資料契約；存在型別不表示 M0 要建完整 store/service。

角色為重要人物：頭像、名稱、職業、能力、特性、薪資、所屬艦隊。水手為 Crew Resource，不逐人建名冊。船隻含貨艙、速度、航程、耐久、防衛、水手需求。所有能力百分比、薪資、船價、維修、合成與疊加公式都是後續 Config Placeholder。

可保留先前人物／船型示例作構想，不當初始資產。Recruitment 流程為城市→候選→詳情→雇用→指派；未在 M0 實作。

## 更後續版本

V2.5 第二商隊、自動貿易、分店、商會、影響力。V3 是否加入戰爭／外交／海戰另定。海盜在 V1 只作 Risk Event，不要求武器裝備、海戰 AI 或大型 Battle Architecture。
