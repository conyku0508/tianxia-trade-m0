# User Flow｜v1.1

## M0 必須完整可操作

Map → 點泉州 → City Bottom Sheet → Market → Buy → Cargo → Intelligence → Route → Prepared。

1. /map 第 12 天、泉州、現金 5000、載重 0/100。
2. 點泉州，Sheet 顯示城市與普通茶葉／瓷器／絲綢方向；「進入市場」。
3. 選普通茶葉 2 單位，M0 單價 360，稅 ceil(720×0.05)=36，總支出 756，重量 2。
4. Confirm Trade Modal 確認後，現金 4244，茶葉 2、平均成本 378、庫存 18、載重 2/100。
5. Cargo 讀同一 store：總成本 756、稅前估值 720、未實現盈虧 −36。
6. Intelligence 顯示其他城市 knownPrice 與 observedDay，馬六甲茶葉 500、第 10 天觀察→2 天前；非即時承諾。
7. 選泉州→琉球路線，顯示 3 天、旅費 120、風險 8%。
8. 「準備前往」保存 prepared，不扣旅費；Header 仍泉州／第12天／4244，Cargo 仍茶葉2。

詳細 fixture 與驗收見 22；全部數值是 Mock Config。

## 交易例外與返回

Quantity Control 提供 +/−、整數輸入與 MAX；0、空值、非整數、負值及非有限數不提交。Buy 超過現金／庫存／載重，Sell 超過持有，均顯示原因且不改狀態。

確認前再次透過 service 取得同一快照與預覽；若快照已變，顯示最新摘要並要求重新確認，不靜默成交。取消 Modal 返回原交易 Sheet，取消 Sheet 不改資產；關閉後不要保留假購買結果。

成功提示跳到 Cargo 可用，但不強迫自動跳頁。連點確認需 pending guard，避免同一確認重複成交。

## M0 Sell 驗收

完成上述購買後賣 1 茶葉：本金 360、稅18、淨收入342，現金4586，持有1、平均成本378、庫存19、載重1。這是額外驗收分支；Route 主流程在全新 fixture 上採前節結果。

## 未來完整流程

正式 V1：準備→出發→時間與費用→Risk Event→抵達→當地交易。V1.5：City→Investment→Choose→Confirm→Upgrade→Special Goods。V2：City→Recruitment→Character→Hire→Assignment。

後兩條流程只保留規格／wireframe，不在 M0 建 service 或付費結果。
