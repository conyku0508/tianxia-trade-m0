# Roadmap｜v1.1

2026-10-26 Review 已確立以下版本排序，取代早期相互衝突的分期。歷史見 17 與 sources。

| 版本 | 主題 | 範圍 |
|---|---|---|
| M0 | Mobile Frontend Prototype | AppShell、World Map、City Bottom Sheet、Market、Cargo、Intelligence、Route Planning 的可操作流程 |
| V1 | 核心貿易 | 世界地圖、城市、30 一般商品槽位、動態價格、市場、貨艙、航線、情報差、時間流逝、基本事件 |
| V1.5 | 城市投資 | 商業、防衛、港口發展、城市成長、高階特殊商品 |
| V2 | 人物與商業艦隊 | 角色、水手、船隻、旗艦／商船／護衛船、艦隊編成 |
| V2.5 | 大型商業經營 | 第二商隊、自動貿易、分店、商會、城市影響力 |
| V3 | 之後再決定 | 戰爭／外交／海戰是否加入，尚未承諾 |

倉庫僅保留於歷史紀錄，本次不自動列入開發承諾。海盜只作 Risk Event。

## M0 執行順序

M0-A App Shell → M0-B World Map → M0-C Market → M0-D Cargo → M0-E Intelligence → M0-F Route → M0-G Integration。

每個階段均依：1 Wireframe → 2 Static UI → 3 Responsive → 4 Mock Data → 5 Interaction → 6 Store → 7 Game Logic → 8 Real Data。

此處第 7 步在 M0 僅指最小 mock service，第 8 步為後續接線位置，正式資料不在 M0 驗收前置條件。階段詳見 21。

## M0 必須完成與刻意延後

必須完成：五個固定入口；泉州買賣、貨艙與 Header 同步；外地舊情報；可達路線、費用、時間、風險與「已準備」狀態；小螢幕及桌面可用。

M0 不要求實際抵達、世界市場推進、完整事件機率、投資結算、招聘、艦隊、SaveService 或 PWA 離線。Sailing、Investment、Fleet、Recruitment 提供 wireframe，不納入必要可操作頁面。

經濟平衡、正式價格、投資門檻、角色公式、艦隊數值及最終商品資料使用 Config Placeholder，不阻擋任何 M0 階段。
