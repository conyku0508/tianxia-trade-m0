# Frontend Implementation Plan｜v1.1

**M0可以立即開始。** 本計畫是開發順序與完成條件，不是需要使用者逐階段批准的關卡。支援檔可直接複製後拆至src目錄。

## 全階段共通執行序

1 Wireframe → 2 Static UI → 3 Responsive → 4 Mock Data → 5 Interaction → 6 Store → 7 Game Logic → 8 Real Data。

先看到畫面，再掛功能；第7步M0限mock service，第8步正式資料／經濟引擎延後。不要同時做完整UI、完整經濟引擎與全部正式資料。

每次修改前先列Data／UI／Logic與「本次預計修改檔案」，然後執行。使用Placeholder不需再問；契約、fixture與Suggested Tokens依20／22／11。

## Phase M0-A｜App Shell

工作：Vue 3、Vite、TypeScript、Pinia、Vue Router、Tailwind；Header、Bottom Navigation、Layout、Router、Placeholder Assets。

預計檔案：AppShell.vue、TopStatusBar.vue、BottomNavigation.vue、components/ui/*、router/routes.ts、styles/tokens.css、package.json／lockfile。

執行：六個路由可開啟，五個主入口一致；以靜態展示值與空容器先完成390×844版面，再補Responsive。此時無資產行為，測試標頭值不寫死到正式Page。

完成條件：五入口切換、active狀態、Header／底部安全區正常。/route不是第六入口。

## Phase M0-B｜World Map

工作：Map、City Marker、Player Position、City Bottom Sheet。

預計檔案：MapPage.vue、CityMarker.vue、CityCard.vue、BottomSheet.vue、data/cities.ts、data/routes.ts。

執行：按W01／W02先靜態地圖與marker，再Responsive，然後data fixture與選城互動。20城摘要、泉州玩家位置、兩條路線。

完成條件：可點泉州，開Sheet進市場；外地有路線才顯示查看航線。不需完整世界連通或地圖SDK。

## Phase M0-C｜Market

工作：Goods List、Price、Stock、Buy／Sell、Quantity Control、Transaction Summary，全用Mock Data。

預計檔案：MarketPage.vue、GoodsRow.vue、TradeControl.vue、ConfirmDialog.vue、data/goods.ts／marketConfig.ts、MarketService.ts、TradeService.ts、player/cargo/market/game stores。

執行：先靜態商品列與摘要，再RWD、fixture、按鈕／數量、Pinia與mock service。+/-、整數輸入、MAX；稅／資產檢查不放UI。

完成條件：03與22買賣算例通過；取消不改資產，無效數量／現金／庫存／載重受限，確認不能重複成交。

## Phase M0-D｜Cargo

工作：Goods、Quantity、Average Cost、Local Value、Weight、Total Cargo。

預計檔案：CargoPage.vue、CargoRow.vue、ProgressBar.vue、TradeService.cargoSummary selector。

執行：先靜態空／有貨兩狀態，再RWD、接同一cargoStore；不得重新複製Market交易資料。

完成條件：買2茶後Header／Market／Cargo同步；成本756、稅前估值720、盈虧−36。

## Phase M0-E｜Intelligence

工作：Known Price、Observed Day、Rumor、World Event、Price Trend。

預計檔案：IntelligencePage.vue、KnowledgeRow.vue、PriceTrend.vue、RumorCard.vue、EventCard.vue、knowledgeStore.ts、data/events.ts。

執行：先靜態卡與趨勢，再RWD、mock已知歷史。SVG即可；先標示舊情報，不接全球即時市場。

完成條件：第12天能顯示2／3天前；unknown不是0；事件只展示；有路線能跳Route。

## Phase M0-F｜Route

工作：Route Selection、Travel Time、Travel Cost、Risk、Prepared。

預計檔案：RoutePage.vue、RouteSummary.vue、RouteService.ts、routeStore.ts。

執行：先W06靜態摘要，再Responsive、兩路線mock、選擇與準備，最後service合法性檢查。

完成條件：泉州→琉球3天／120／8%可準備；只改routeStore，不扣錢、不換城、不推天數。

## Phase M0-G｜Prototype Integration

工作：Map→City→Market→Buy→Cargo→Intelligence→Route完整互動。

預計檔案：整合必要頁、stores／services、README、適度的service與流程測試；只修整合涉及檔案。

執行：清fixture開跑，依22正向與失敗分支驗收；完成六尺寸、鍵盤／Sheet、取消／重入與重設。檢查任何data／logic是否落入Vue。

完成條件：可啟動、可操作、README明示memory-only與mock；附真實測試結果與已知限制。


## 品質與範圍守門

三層分離、SSOT、共用穩定元件是必達要求。TypeScript檢查、build、必要service測試與實際瀏覽器主流程都要做；不能只因build成功就稱手機驗收完成。無法進行的環境檢查如實報告，不無限重複同一測試。

M0記憶體即可，刷新重設並明示；不因存檔方式未選停工。20城市與30商品資料可以placeholder，完整地理連通及正式供需不阻擋。

## 未納入本階段

實際Sailing／到港結算、隨機價格引擎、世界事件概率、正式持久化、投資扣款、高階商品交易、人物招聘、水手薪資、多船／Fleet、Battle、自動商隊、多人、後端。未來在原有service/config介面逐步接入。

只有架構衝突、不可逆資料、刪除既有功能或大幅改核心玩法時，停受影響工作提出問題；合理原型預設持續執行並記錄。
