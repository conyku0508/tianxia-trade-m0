# 遊戲定位｜v1.1

專案：work_天下商路遊戲討論。遊戲暫名《海路商途／天下商路》；名稱不阻擋 M0。早期 Trade Winds 僅作歷史別稱。

## 核心方向維持

手機優先、單機、世界／區域貿易策略，以貿易經營為主，後續擴充城市投資與商業艦隊。V1 地理範圍保留東亞、東南亞與印度洋西段；使用城市節點與路線，不要求地理引擎。

完整遊戲循環：情報→價差判斷→買入→貨艙→路線→航行與時間推進→抵達→賣出→獲利。後續投資提高城市發展、開放高階特殊商品及人才，再擴大商路。

## M0 已授權立即開發

狀態：**M0 Mobile Frontend Prototype Ready for Codex**。

第一條必要流程：World Map→點泉州→City Bottom Sheet / City Detail→Market→Buy→Cargo→Intelligence→Route Planning→準備前往下一城。

驗證手機 UI、Navigation、資訊密度、操作手感、共用元件、Responsive、狀態管理。M0 不需要完整經濟引擎、實際出航結算或正式資料；先用 Mock Data、Placeholder Asset、Config。

## V1 與 M0 的數量邊界

V1 保留 20 城、30 個一般商品槽位、單玩家單商隊／船隊。03 提供單一 V1 Candidate Dataset；木材保留，馬匹排除一般 V1 Commodity。

M0 可顯示 20 城與 30 商品的 mock 資料，但只有泉州起點與少量目的港需要完整可操作。22 提供可執行驗收資料；其他節點可讀摘要，不需先完成全部路線。

## 視覺與平台

四張世界地圖、泉州市場、貨艙、情報圖為使用者已正面確認的 Approved Visual Direction Reference。它們是視覺方向 Source of Truth，非 Final Pixel-Perfect UI。可因可讀性、Responsive、操作與技術限制調整配置。

390×844 手機直式優先；平板、桌面依 13 延展。Web／PWA 是方向；M0 不要求離線安裝、Service Worker、帳號、後端或跨裝置存檔。

## V1 用語

V1 使用「商隊／船隊」，只需目前交通工具、貨艙、速度、航程、載重、航行時間與基本風險。不建完整 Fleet Management。V2 才引入旗艦、多船、角色、水手與正式艦隊編成。

海盜先以 Risk Event 表達，不建立戰鬥、外交、國戰或大型 RPG。
