# 三層架構、SSOT 與 Component Reuse｜v1.1

## 目錄與依賴

```text
src/
  contracts/game.ts          共用型別（20／support/contracts.ts）
  data/
    goods.ts cities.ts routes.ts events.ts
    marketConfig.ts gameConfig.ts
    investment.ts           V1.5 配置預留，不必 M0 建檔
  services/
    MarketService.ts         M0 取固定 mock 報價
    TradeService.ts          preview / buy / sell / selectors
    RouteService.ts          list / preview / prepare / cancel
  stores/
    gameStore.ts             currentCityId / currentDay
    playerStore.ts           money / name / transport
    cargoStore.ts            items
    marketStore.ts           items / revision
    cityStore.ts             city definitions；唯讀
    knowledgeStore.ts        records / rumors / events；M0 唯讀
    routeStore.ts            selectedRouteId / idle|prepared
    uiStore.ts               sheets / draft / pending；非資產
  components/ui/             Button / Panel / Modal / Sheet ...
  components/map/            CityMarker / CityCard
  components/trade/          GoodsRow / TradeControl
  components/cargo/          CargoRow
  components/intelligence/   KnowledgeRow / PriceTrend / EventCard
  pages/                     Map / Market / Cargo / Intelligence / Route / Menu
  router/                    routes.ts
```

Data/Config → Service；Page/Component → Store selector + Service command；Service 透過注入的 state port 讀寫 store，不 import .vue 或依賴 Router。Store 初始化由 data factory clone；不能直接 mutate 被共用的 fixture。

## 1 Data / Config

城市、商品、航線、船隻、角色、事件、投資、解鎖、平衡設定。M0 實際需要 goods/cities/routes/events 與 mockConfig。數值不得寫入 .vue。候選資料標 candidate，mock 數值標 mock，未確認公式標 placeholder。

## 2 UI / Presentation

Layout、Button、Card、Modal、Bottom Sheet、Responsive、顯示資料、click。可處理 Selected、Active、Hover、展開、動畫、輸入字串與鍵盤焦點。輸入 parse 可產生 intent；價格、MAX、稅、資產估值、載重、解鎖判斷由 service 提供。

## 3 Game Logic / Service

M0 MarketService 讀固定當地價格；TradeService 做預覽、現金／庫存／載重檢查與成交；RouteService 做可達性、時間、成本、風險與準備。

未來 InvestmentService、FleetService、RecruitmentService、EventService、SaveService 按版本新增；M0 不建立空殼群以假裝實作完整系統。

```text
Market UI → TradeService.preview() → TradePreview
確認 Modal → TradeService.buy()/sell()
→ 重讀 state / 檢查 revision、價格、庫存、金錢、貨艙
→ 同一同步 command 更新 Store（中間不 await）
→ Header / Market / Cargo 讀同一狀態重新 render
```

## Single Source of Truth

| 狀態 | 唯一來源 | 規則 |
|---|---|---|
| 現金 | playerStore.money | Header／Market／Menu 不備份 money |
| 持貨 | cargoStore.items | 貨艙與市場持有量取同一來源 |
| 城市／天數 | gameStore.currentCityId / currentDay | 市場使用本城，不用 selectedCityId |
| 市場庫存／報價 | marketStore.items + revision | 不能每頁各初始化一次 |
| 城市基礎資料 | cityStore.byId | static data 的唯讀索引 |
| 已知情報 | knowledgeStore.records | 外地行情只讀此處 |
| 準備路線 | routeStore | UI 不另存第二份準備結果 |
| 草稿／選中 | uiStore 或元件 local transient | 不當作已成交／資產 |

Player 型別是 snapshot／service input，不另存一份 player.cargo、player.currentCityId。TradeService snapshot getter 組合上述 store；不可把 snapshot 永久寫回成第二套 store。不保存 usedWeight／totalValue 等重複可推導狀態，改 service selector。

## Component Reuse

穩定可共用：AppShell、TopStatusBar、BottomNavigation、GamePanel、PrimaryButton、IconButton、GoodsRow、TradeControl、CargoRow、PriceTrend、RumorCard、EventCard、ProgressBar、Modal、BottomSheet、ConfirmDialog、Toast。

CharacterCard／ShipCard／InvestmentCard 可在後續對應版本加入。共用 UI 不含交易或艦隊規則；每頁不得複製同樣 Button／Panel。

## 修改隔離

| 需求 | 主要修改 | 不應連動 |
|---|---|---|
| 商品數值 | data/goods.ts／marketConfig.ts | MarketPage 版面 |
| 商品列太擠 | MarketPage.vue／GoodsRow.vue | MarketService／goods data |
| 香料價格波動太大 | marketConfig.ts／MarketService.ts（接正式算法時） | Market UI |
| 城市投資 | investment.ts + InvestmentService | 無關 Cargo／Map |

每次修改先列 Data／UI／Logic 分類與預計檔案；不為小需求大規模重構。服務契約、操作後條件與錯誤碼見 20。
