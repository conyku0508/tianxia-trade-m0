# Codex 開發入口｜v1.1

**M0 Mobile Frontend Prototype Ready for Codex。可以立即開始 M0，不需再次要求使用者確認數值或同意開工。**

你是本專案前端工程師。請依本文件包建立可執行、手機優先的 Vue 原型，完成以下主流程：

```text
World Map → 點選泉州 → City Bottom Sheet
→ Market → Buy → Cargo → Intelligence → Route Planning → Prepared
```

## 先讀，然後實作

閱讀 00、06、19、20、21、22，再按需讀 03／10／11／12／13。舊 sources 是歷史資料，不是開發入口；本文件與2026-10-26 Review取代v1「先等確認」規則。不要只回報計畫／問題後結束。

## 技術與產物

Vue 3、Vite、TypeScript、Pinia、Vue Router、Tailwind。以相容穩定版本初始化並保存lockfile。提交可啟動專案、README、fixture初始化、各主要畫面、共用UI及最小service。可在現有repo適當目錄實作；沒有repo則建立獨立原型目錄，不覆蓋文件包或既有功能。

README需列執行方式、M0模擬資料、memory-only重新載入重設、哪些功能延後，以及實際完成／未完成驗證。底部五入口固定地圖／市場／貨艙／情報／選單。

## 原型優先

依 **Wireframe → Static UI → Responsive → Mock Data → Interaction → Store → Game Logic → Real Data** 執行。第7步M0只需最小mock service；第8步正式引擎／資料留後續，不當交付前置。

使用03單一30槽位V1 Candidate Dataset與22 fixture。經濟平衡、正式價格、投資正式門檻、角色公式、艦隊數值、最終商品資料以Mock Data／Config Placeholder處理，不能因此停工。先看到畫面，再掛功能。

四張世界地圖／泉州市場／貨艙／情報圖為Approved Visual Direction Reference，視覺Source of Truth；允許可讀性／Responsive／操作／技術調整，不逐像素複製。若圖檔未掛載，依11 Suggested Tokens與Placeholder Asset完成M0，不重新索取視覺批准。

## 三層架構與唯一狀態

Data/Config：城市、商品、路線、事件、數值。UI/Presentation：Layout、顯示與操作。Logic/Service：計價、交易、資產、路線、解鎖、存檔。

M0建MarketService、TradeService、RouteService即可。Page不得硬寫遊戲資料、稅率、貨物估值、MAX或交易結果。穩定Button、Panel、Sheet、Modal、Toast等共用，不逐頁複製。

playerStore.money、cargoStore.items、gameStore.currentCityId/currentDay、marketStore.items/revision、cityStore、knowledgeStore、routeStore各有唯一責任。Header／Market／Cargo不備份資產。詳見12與20。

## 修改前規則（每次都適用）

先判斷Data／UI／Logic，再列「本次預計修改檔案」，然後直接執行。這不是等待批准的關卡。

例如「市場商品列太擠」→UI：MarketPage.vue、GoodsRow.vue；不要動MarketService或goods資料。

例如「香料波動太大」→Logic/Config：marketConfig.ts、MarketService.ts；不要動Market UI。M0尚未啟用波動時，先釐清目前展示資料來源，再改對應mock config，不憑空建完整引擎。

## M0 必達與驗收

- 20城市marker／摘要可用mock；泉州實際可交易。30商品槽位存在，木材保留、馬匹不進一般列表。
- 買／賣／數量／MAX／交易摘要／確認與取消。現金、庫存、持貨、平均成本與重量同步。
- Intelligence顯示外地已知價、觀察時間、傳聞、事件、有限已知趨勢；不偷讀外地即時價。
- Route有選擇、天數、費用、風險、prepared狀態。準備不扣款、不換城市、不推時間。
- 依22算例檢查正常與超額／取消／重複確認；完成指定六尺寸驗收。能測什麼就實測，報告限制，不用靜態檢查冒充瀏覽器驗收。

## 不提前實作

完整經濟引擎、正式平衡、實際航行結算與完整Risk Event概率、正式存讀檔、PWA離線可後續接。M0不建Investment／Fleet／Recruitment runtime。V1.5城市投資，V2角色／水手／多船／旗艦，V2.5第二商隊／自動貿易，V3戰爭外交海戰另定。

V1使用商隊／船隊，海盜以Risk Event處理。不加大型RPG、外交、國戰、多人或後端帳號。

## 何時才停止提出問題

只有架構衝突、資料不可逆、需要刪除既有功能、大幅改變核心玩法才暫停受影響部分並說明；其他工作繼續。正式數值、token、最終商品資料、未來頁面規則皆不是阻擋。

禁止為小功能大幅重構整個專案，禁止把mock參數說成正式定案。完成後報告可操作流程、實際驗證與剩餘範圍。
