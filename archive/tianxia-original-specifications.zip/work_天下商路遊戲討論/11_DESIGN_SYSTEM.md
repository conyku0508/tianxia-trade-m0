# Design System 初稿

## 來源中的視覺方向

復古策略遊戲、明亮手繪、Pixel Remaster、東方航海貿易氣氛；深墨綠／深藍底、金色框、米白紙張資訊區、紅色重要操作按鈕、清楚商品 icon。大量資訊仍須易讀。

避免過度現代 SaaS Dashboard、強烈 Material Design、Cyberpunk、3D 寫實、過多華麗裝飾，以及每頁大量不同插圖。Mockup 參考方向，不逐像素照抄。

四張原圖未取得，以下不可稱為從圖片抽樣的既定設計。

## 待審設計 Tokens

以下數值全部為【本次整理提案】，不是歷史定稿：

| Token | 候選值／方向 | 用途 |
|---|---|---|
| color.bg | #123C36 | 深墨綠主背景 |
| color.navy | #152D45 | 地圖海色／次背景 |
| color.paper | #F4E8CF | 資訊面板 |
| color.ink | #252B2A | 紙面文字 |
| color.gold | #BA9855 | 裝飾框、分隔，不作小字主色 |
| color.action | #9F3731 | 主要操作 |
| typography.body | 16px、行高 1.5 | 主要資訊 |
| typography.secondary | 14px | 補充說明 |
| typography.title | 20–24px | 畫面標題 |
| spacing | 4／8／12／16／24px | 系統間距 |
| touch.min | 44×44px | 操作區候選最小尺寸 |
| radius | 4–8px | 面板與按鈕 |

字體以繁體中文字可讀性與合法可用為先；標題可具復古氣質，內文不採難辨識點陣字。數字使用對齊排版，讓價量容易比較。未選定字型，亦未測對比度，不宣稱完成視覺無障礙驗證。

## 元件樣式規則

- GamePanel：米白內容、細金框、清楚標題；紋理不得干擾價格與小字。
- Button：Primary 紅色、Secondary 紙面描邊、Disabled 有文字原因；Loading 避免重複交易。
- Card／Table：手機商品列用可換行卡片，寬螢幕才展多欄；相同欄位位置固定。
- Icon：同一風格、輪廓清楚，商品 icon 必須伴隨文字；未知與鎖定使用明確符號。
- Status：上漲／下跌搭配箭頭與文字，不能只靠紅綠；舊情報使用時間標記。
- Modal／Bottom Sheet：紙面內容、標題、關閉、清楚操作層級，背景與前景可辨。
- Navigation：五個標籤與 icon 固定；選中態同時改文字／外框，避免只靠顏色。

## 視覺驗收提案

以地圖、市場、貨艙、情報四頁檢查字級、交易按鈕、長商品名、貨幣大數字、舊情報與鎖定商品；取得原圖後再做方向比對。未生成新 mockup 冒充舊圖。
