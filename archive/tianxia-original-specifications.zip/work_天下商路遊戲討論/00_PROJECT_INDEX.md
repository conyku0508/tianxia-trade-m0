# work_天下商路遊戲討論

整理日期：2026-10-25（Asia/Taipei）｜階段：專案初始化、前端規劃與交接草案。

## 使用方式

先閱讀本索引、01、02、17，再閱讀 06–15。16 為本次可直接交給 Work 的完整主提示詞；sources 保存可取得的歷史提示詞與逐則對話。

本文件包是本機可移轉的專案資料。ChatGPT 專案容器是否已建立、雲端 Work 聊天是否已建立、內容是否已存成雲端檔案，分別記錄於 18_IMPORT_STATUS.md，不互相代替。

## 狀態標記

- 【使用者明示】本次要求或原對話使用者明確提出的方向。
- 【原對話規劃】前次助理提出的規格、建議或示例，保留作規劃基線，並非逐項取得使用者定案。
- 【本次整理提案】為使前端規格可審閱而補上的配置與邊界，不新增大型玩法；仍待確認。
- 【待確認／來源缺漏】互相衝突、數值未定、附件未取得，不能當作正式遊戲資料。

## 文件索引

| 文件 | 用途 |
|---|---|
| [01_GAME_OVERVIEW.md](01_GAME_OVERVIEW.md) | 定位、核心循環與範圍 |
| [02_ROADMAP.md](02_ROADMAP.md) | V1 至 V3、前後分期差異 |
| [03_WORLD_AND_ECONOMY.md](03_WORLD_AND_ECONOMY.md) | 20 城、商品原表、價格、情報與事件 |
| [04_CITY_INVESTMENT.md](04_CITY_INVESTMENT.md) | 商業、防衛、港口、特殊發展 |
| [05_FLEET_AND_CHARACTERS.md](05_FLEET_AND_CHARACTERS.md) | 角色、水手、船隻與編成 |
| [06_FRONTEND_OVERVIEW.md](06_FRONTEND_OVERVIEW.md) | 手機前端目標及技術方向 |
| [07_INFORMATION_ARCHITECTURE.md](07_INFORMATION_ARCHITECTURE.md) | IA 與 Sitemap |
| [08_SCREEN_MAP.md](08_SCREEN_MAP.md) | 17 種畫面與入口 |
| [09_USER_FLOW.md](09_USER_FLOW.md) | 跑商、投資、招募流程 |
| [10_SCREEN_SPEC.md](10_SCREEN_SPEC.md) | 畫面配置、操作及狀態 |
| [11_DESIGN_SYSTEM.md](11_DESIGN_SYSTEM.md) | 視覺方向與待確認設計規則 |
| [12_COMPONENT_ARCHITECTURE.md](12_COMPONENT_ARCHITECTURE.md) | 元件職責、狀態與資料邊界 |
| [13_RESPONSIVE_SPEC.md](13_RESPONSIVE_SPEC.md) | 手機、平板、桌面配置 |
| [14_ASSET_REQUIREMENTS.md](14_ASSET_REQUIREMENTS.md) | 素材、mockup 與缺件 |
| [15_CODEX_FRONTEND_HANDOFF.md](15_CODEX_FRONTEND_HANDOFF.md) | 可交付 Codex 的開發前摘要 |
| [16_WORK_MASTER_PROMPT.md](16_WORK_MASTER_PROMPT.md) | 本次完整 Work 任務提示詞 |
| [17_SOURCE_AND_DECISION_LOG.md](17_SOURCE_AND_DECISION_LOG.md) | 來源、差異與決策清單 |
| [18_IMPORT_STATUS.md](18_IMPORT_STATUS.md) | 實際建立與匯入狀態 |

## 證據範圍

來源聊天：對話_天下商路遊戲_開發討論；ID：6addab47-8e60-83e8-ac74-2dd75c3eb7c2。讀取工具回傳 5 個 turn，hasMore=false，attachments 為空。這表示目前回傳範圍已讀完，不保證圖片或先前檔案均已回傳。

本次保留兩段完整歷史提示詞：早期 CODEX_MASTER_PROMPT、後期 FRONTEND MASTER SPEC。另保留原對話可取得全文；未找到既有 Markdown／DM 附件，因此本次文件是重新整理，不宣稱原檔已搬移。

## 開發狀態

未開始正式遊戲開發、未部署、未完成玩法測試。先審閱前端規格與待確認清單，再決定程式開發範圍。歷史 Codex 提示詞內的「直接開發」語句僅供追溯，不自動成為本階段執行指令。
