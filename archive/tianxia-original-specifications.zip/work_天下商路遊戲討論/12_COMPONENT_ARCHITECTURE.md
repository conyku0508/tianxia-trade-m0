# Component Architecture

元件名稱來自 S4；職責、輸入與狀態分層為【本次整理提案】。本文件是設計，不是已建立的程式碼。

| 元件 | 職責／主要輸入 | 輸出互動 |
|---|---|---|
| AppShell | 頁面、導覽、覆蓋層容器 | 導覽切換 |
| TopStatusBar | 天數、現金、城市、載重 | 船隊入口（待審） |
| BottomNavigation | 五入口、目前頁 | navigate |
| GamePanel | 標題、內容 slots | 無遊戲邏輯 |
| CityMarker | 城市位置、選中／可達狀態 | selectCity |
| CityCard | 城市摘要、已知情報時間 | openMarket／planRoute |
| GoodsRow | 商品、當地報價、庫存、持有 | chooseBuy／chooseSell |
| TradeControl | 模式、數量、上限、預覽總額 | changeQuantity／confirm／cancel |
| CargoRow | 持貨、成本、重量、估值基準 | 可進本城市場 |
| PriceTrend | 已知歷史點、觀察日 | 無即時世界查詢 |
| RumorCard | 城市、商品、已知價、時間 | 查看相關情報 |
| EventCard | 事件與已公開影響 | acknowledge |
| ProgressBar | 現值、上限、文字標籤 | 無 |
| ShipCard | 船型與核心數值 | openShip |
| CharacterCard | 職業、能力、薪資、指派 | openCharacter |
| InvestmentCard | 方向、現值、成本、效果 | chooseInvestment |
| Modal | 標題、內容、焦點與關閉 | close |
| BottomSheet | 展開狀態、內容、操作區 | close |
| Toast | 非阻塞結果提示 | dismiss |
| ConfirmDialog | 行為摘要、確認／取消 | confirm／cancel |

## 資料與狀態

1. Static World：城市、商品、路線、事件、gameConfig，保留正式 ID；未定資料不可偷偷補齊。
2. Game State：現金、城市、天數、持貨、世界市場狀態；未來 fleet／ships／characters／cityDevelopment。
3. Knowledge：城市商品 observedPrice、observedDay 與已知歷史，只向情報 UI 提供已公開資料。
4. UI State：選中城市、Sheet、交易草稿數量、分頁、捲動位置；不與持有資產混用。
5. Persistence：保存／讀取介面與錯誤狀態，實際方案待選。

## 邏輯邊界

市場計價、交易、移動、事件、存檔與 UI 分離。UI 發出意圖，邏輯檢查合法性，再一次更新金錢、持貨及庫存；不能由不同元件各自扣款。PriceTrend 不可直接讀取尚未取得的遠方市場價格。

Pinia stores 的具體檔名、資料型別與模組拆法由核准後工程設計決定。預留 fleetId 與解鎖條件結構不代表提前實作自動商隊。

## 待定介面

TradePreview 需包含費用與取整，但規則未定；MarketSnapshot 更新時點未定；Crew 與 Fleet 聚合公式未定。應先定義可接受資料契約再實作，不能把示例數值當測試真值。
