# Screen Map

原前端提示詞列出 17 種主要 Screen。以下補上入口與呈現形式作為【本次整理提案】，識別碼不是已存在路由。

| ID | 畫面 | 入口 | 形式 | 版本基線 |
|---|---|---|---|---|
| S01 | Splash / Main Menu | 啟動 | 全頁 | V1 |
| S02 | World Map | 地圖導覽 | 主頁 | V1 |
| S03 | City Detail | 點城市 | Bottom Sheet／詳情 | V1 摘要；未來擴充 |
| S04 | Market | 市場／本城卡 | 主頁＋交易 Sheet | V1 |
| S05 | Cargo | 貨艙導覽 | 主頁 | V1 |
| S06 | Intelligence | 情報導覽 | 主頁＋分區 | V1 |
| S07 | Route Planning | 城市／航線 | Sheet／詳情 | V1 |
| S08 | Sailing | 確認出發 | 旅程頁 | V1 |
| S09 | Random Event | 航行／市場事件 | Modal | V1 |
| S10 | City Investment | 城市詳情 | 次頁 | V1.5 |
| S11 | Fleet | 頂部船隊入口 | 次頁 | V2；V1 只需單隊狀態 |
| S12 | Ship Detail | 船卡 | 次頁／面板 | V2 |
| S13 | Character | 艦隊人物 | 列表＋詳情＋指派 | V2 |
| S14 | Recruitment | 城市 | 列表＋詳情 | V2 |
| S15 | Player Profile | 選單 | 次頁 | V1 |
| S16 | Settings | 首頁／選單 | 次頁 | V1 |
| S17 | Save / Load | 選單 | 次頁 | V1 |

底部「選單」是 S15–S17 的容器入口，不將 17 種畫面誤算成 17 個固定導覽按鈕。交易、人物詳情與指派是子狀態，仍需規格化，但不新增大型玩法。

S07/S08 可採簡易日數跳轉或倒數，原對話未定案。陸路與海路在地圖上已提及，但水手／艦隊系統如何適用陸路尚待釐清。
